import { Stack } from "expo-router";
import { useContext } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { AuthContext, AuthProvider } from "../contexts/AuthContext";

function SessionNavigator() {
  const { firebaseUser } = useContext(AuthContext);

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Protected guard={!firebaseUser}>
        <Stack.Screen name="index" />
      </Stack.Protected>

      <Stack.Protected guard={!!firebaseUser}>
        <Stack.Screen name="home" />
      </Stack.Protected>
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <SessionNavigator />
      </AuthProvider>
    </SafeAreaProvider>
  );
}
