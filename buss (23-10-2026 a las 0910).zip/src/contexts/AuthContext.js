
import { onAuthStateChanged } from "firebase/auth";
import { createContext, useEffect, useState } from "react";

import { auth } from "../firebase/FirebaseConfig";
import { login, logout } from "../services/auth.service";
import {
    getPersonaActual,
    getUsuarioActual,
} from "../services/user.service";

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [firebaseUser, setFirebaseUser] = useState(null);
    const [user, setUser] = useState(null);
    const [persona, setPersona] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        let active = true;
        let session = 0;

        const unsubscribe = onAuthStateChanged(
            auth,
            async (authenticatedUser) => {
                const currentSession = ++session;
                const isCurrent = () =>
                    active && session === currentSession;

                setLoading(true);
                setError(null);
                setFirebaseUser(null);
                setUser(null);
                setPersona(null);

                if (!authenticatedUser) {
                    if (isCurrent()) setLoading(false);
                    return;
                }

                try {
                    const usuario = await getUsuarioActual();

                    if (!isCurrent()) return;

                    if (usuario.estado !== true) {
                        throw new Error("Usuario deshabilitado");
                    }

                    if (!["tractores", "furgones"].includes(usuario.area)) {
                        throw new Error("Área de taller no autorizada");
                    }

                    if (!usuario.dni || !usuario.sucursal) {
                        throw new Error(
                            "El usuario no tiene DNI o sucursal asignada"
                        );
                    }

                    const personaActual = await getPersonaActual(
                        usuario.dni
                    );

                    if (!isCurrent()) return;

                    if (String(personaActual.id) !== String(usuario.dni)) {
                        throw new Error("La persona asociada no coincide");
                    }

                    setUser(usuario);
                    setPersona(personaActual);
                    setFirebaseUser(authenticatedUser);
                } catch (err) {
                    if (!isCurrent()) return;

                    setError(err.message);
                    await logout().catch(() => { });
                } finally {
                    if (isCurrent()) setLoading(false);
                }
            }
        );

        return () => {
            active = false;
            session++;
            unsubscribe();
        };
    }, []);

    return (
        <AuthContext.Provider
            value={{
                firebaseUser,
                user,
                persona,
                area: user?.area ?? null,
                sucursal: user?.sucursal ?? null,
                loading,
                error,
                login,
                logout,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}
