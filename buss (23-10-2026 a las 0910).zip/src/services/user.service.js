
import { auth } from "../firebase/FirebaseConfig";

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, "");

const getHeaders = async () => {
    if (!auth.currentUser) {
        throw new Error("Usuario no autenticado");
    }

    const token = await auth.currentUser.getIdToken();

    return {
        Authorization: `Bearer ${token}`,
    };
};

const getResource = async (path) => {
    if (!API_URL) {
        throw new Error("Falta EXPO_PUBLIC_API_URL");
    }

    const response = await fetch(`${API_URL}${path}`, {
        headers: await getHeaders(),
    });

    if (!response.ok) {
        throw new Error(
            `Error al consultar ${path}: ${response.status}`
        );
    }

    return response.json();
};

export const getUsuarioActual = async () => {
    const uid = auth.currentUser?.uid;

    if (!uid) {
        throw new Error("Usuario no autenticado");
    }

    return getResource(`/users/${encodeURIComponent(uid)}`);
};

export const getPersonaActual = async (dni) => {
    if (!dni) {
        throw new Error("El usuario no tiene DNI asociado");
    }

    return getResource(`/personas/${encodeURIComponent(dni)}`);
};
