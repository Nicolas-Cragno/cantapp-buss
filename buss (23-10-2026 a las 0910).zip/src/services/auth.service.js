
import {
    signInWithEmailAndPassword,
    signOut,
} from "firebase/auth";

import { auth } from "../firebase/FirebaseConfig";

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, "");

export const login = async (dni, password) => {
    if (!API_URL) {
        throw new Error("Falta configurar EXPO_PUBLIC_API_URL");
    }

    const response = await fetch(
        `${API_URL}/api/v1/auth/resolver-usuario`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                usuario: String(dni).trim(),
            }),
        }
    );

    const result = await response.json();

    if (!response.ok || !result.ok || !result.data?.email) {
        throw new Error("No se pudo resolver el usuario");
    }

    const credential = await signInWithEmailAndPassword(
        auth,
        result.data.email,
        password
    );

    return credential.user;
};

export const logout = async () => {
    await signOut(auth);
};
