import PendingForm from "../components/PendingForm";
export default function Screen(){return <PendingForm title="NUEVO REPUESTO" message="Alta y edición de artículos, QR e imágenes."/>;}