import { Stack } from "expo-router";
import { useContext, useEffect, useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import LoadingOverlay from "../components/LoadingOverlay";
import { AuthContext, AuthProvider } from "../contexts/AuthContext";

function Navigator() {
  const { firebaseUser, loading } = useContext(AuthContext);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: "#000" },
        }}
      >
        <Stack.Protected guard={!firebaseUser}>
          <Stack.Screen name="index" />
        </Stack.Protected>

        <Stack.Protected guard={!!firebaseUser}>
          <Stack.Screen name="home" />
          <Stack.Screen name="stock" />
          <Stack.Screen name="ajuste-stock" />
          <Stack.Screen name="trabajos" />
          <Stack.Screen name="unidades" />
          <Stack.Screen name="historial" />
          <Stack.Screen name="documentos" />
          <Stack.Screen name="form-stock" />
          <Stack.Screen name="form-trabajo" />
          <Stack.Screen name="form-documento" />
          <Stack.Screen name="scanner" />
        </Stack.Protected>
      </Stack>

      {mounted && <LoadingOverlay visible={loading} />}
    </>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <Navigator />
      </AuthProvider>
    </SafeAreaProvider>
  );
}
