import { useEffect, useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import BissScreen from "./BissScreen";
import { api, asList } from "../services/api";
export default function BussList({ title, path, filter, detail }) {
 const router=useRouter(), [items,setItems]=useState([]),[query,setQuery]=useState(""),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 async function load(){setLoading(true);setError("");try { const data=asList(await api(path));setItems(filter?data.filter(filter):data); }catch(e){setError(e.message);}finally{setLoading(false);}}
 useEffect(()=>{load();},[path]);
 const visible=items.filter(x=>JSON.stringify(x).toLowerCase().includes(query.toLowerCase()));
 return <BissScreen><View style={{paddingTop:22,gap:12}}><Pressable onPress={()=>router.back()}><Text style={{color:"#ffbd59"}}>← VOLVER</Text></Pressable><Text style={{color:"white",fontSize:27,fontWeight:"800"}}>{title}</Text><TextInput placeholder="Buscar..." placeholderTextColor="#aaa" value={query} onChangeText={setQuery} style={{backgroundColor:"#333",color:"white",borderRadius:10,padding:14}}/><Pressable onPress={load}><Text style={{color:"#ffbd59"}}>Actualizar listado</Text></Pressable>{loading&&<Text style={{color:"white"}}>Cargando...</Text>}{!!error&&<Text style={{color:"#ff9b9b"}}>{error}</Text>}{!loading&&!error&&visible.length===0&&<Text style={{color:"#bbb"}}>Sin resultados.</Text>}{visible.slice(0,250).map((item,i)=><Pressable key={String(item.id||i)} onPress={()=>detail&&router.push({pathname:detail,params:{id:String(item.id)}})} style={{backgroundColor:"#222",padding:16,borderRadius:10,borderWidth:1,borderColor:"#444"}}><Text style={{color:"white",fontWeight:"bold",fontSize:16}}>{item.nombre||item.descripcion||item.patente||item.interno||item.tipo||item.id||"Registro"}</Text><Text style={{color:"#aaa",marginTop:4}}>{item.id}{item.cantidad!==undefined?` · Cantidad: ${item.cantidad}`:""}</Text></Pressable>)}</View></BissScreen>;
}
